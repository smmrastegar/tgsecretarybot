// OtpBar — macOS menu-bar app for tgsecretarybot's OTP board.
//
// Shows the newest verification code in the menu bar itself, copies it
// on click, lists recent codes on right-click, and fires a macOS
// notification (with a Copy button) for every new code. Polls
// GET <server>/api/otp/recent every 4 s with a code-feed token.
//
// Build: bash build.sh   (needs Xcode Command Line Tools)

import Cocoa
import ServiceManagement
import UserNotifications

struct OtpItem: Decodable {
    let id: String
    let code: String
    let sender: String?
    let text: String
    let at: String
    let via: String?
}

final class ClickView: NSView {
    var onClick: (() -> Void)?
    override func mouseDown(with event: NSEvent) { onClick?() }
}

struct OtpResponse: Decodable {
    let items: [OtpItem]
}

final class AppDelegate: NSObject, NSApplicationDelegate, UNUserNotificationCenterDelegate {
    private var statusItem: NSStatusItem!
    private var items: [OtpItem] = []
    private var seen = Set<String>()
    private var firstLoad = true
    private var timer: Timer?
    private var flashTimer: Timer?
    private var lastError: String?
    private var panel: NSPanel?
    private var panelCode: NSTextField?
    private var panelFrom: NSTextField?
    private var panelTimer: Timer?
    private var panelCodeValue = ""
    private let defaults = UserDefaults.standard
    private let isoParser: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime]
        return f
    }()

    private var baseURL: String {
        let s = defaults.string(forKey: "baseURL") ?? "https://bot.text.bz"
        return s.hasSuffix("/") ? String(s.dropLast()) : s
    }
    private var token: String { defaults.string(forKey: "token") ?? "" }
    private var soundOn: Bool { defaults.object(forKey: "sound") == nil ? true : defaults.bool(forKey: "sound") }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        if let button = statusItem.button {
            button.title = "🔑 …"
            button.target = self
            button.action = #selector(statusClicked(_:))
            _ = button.sendAction(on: [.leftMouseUp, .rightMouseUp])
            button.toolTip = "کلیک = کپی آخرین کد · راست‌کلیک = فهرست"
        }

        let center = UNUserNotificationCenter.current()
        center.delegate = self
        center.requestAuthorization(options: [.alert, .sound]) { _, _ in }
        let copy = UNNotificationAction(identifier: "copy", title: "Copy", options: [])
        let category = UNNotificationCategory(identifier: "otp", actions: [copy], intentIdentifiers: [], options: [])
        center.setNotificationCategories([category])

        if token.isEmpty {
            openPairing()
        }
        poll()
        timer = Timer.scheduledTimer(withTimeInterval: 4.0, repeats: true) { [weak self] _ in
            self?.poll()
        }
    }

    func application(_ application: NSApplication, open urls: [URL]) {
        for u in urls where u.scheme == "otpbar" {
            guard let c = URLComponents(url: u, resolvingAgainstBaseURL: false) else { continue }
            let q = c.queryItems ?? []
            guard let t = q.first(where: { $0.name == "token" })?.value, !t.isEmpty else { continue }
            defaults.set(t, forKey: "token")
            if let b = q.first(where: { $0.name == "base" })?.value, !b.isEmpty {
                defaults.set(b, forKey: "baseURL")
            }
            firstLoad = true
            seen.removeAll()
            lastError = nil
            flash("✓ وصل شد")
            poll()
        }
    }

    private func openPairing() {
        if let url = URL(string: "\(baseURL)/otp/pair?auto=1") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc private func openPairingItem(_ sender: Any?) {
        openPairing()
    }

    // MARK: - Status item

    @objc private func statusClicked(_ sender: Any?) {
        let event = NSApp.currentEvent
        let isRight = event?.type == .rightMouseUp || (event?.modifierFlags.contains(.control) ?? false)
        if isRight || items.isEmpty {
            showMenu()
        } else {
            copyLatest()
        }
    }

    private func showMenu() {
        let menu = buildMenu()
        statusItem.menu = menu
        statusItem.button?.performClick(nil)
        statusItem.menu = nil
    }

    private func buildMenu() -> NSMenu {
        let menu = NSMenu()
        if items.isEmpty {
            let empty = NSMenuItem(title: lastError ?? "هنوز کدی نیامده", action: nil, keyEquivalent: "")
            empty.isEnabled = false
            menu.addItem(empty)
        } else {
            let header = NSMenuItem(title: "کدهای اخیر — کلیک = کپی", action: nil, keyEquivalent: "")
            header.isEnabled = false
            menu.addItem(header)
            for item in items.prefix(12) {
                let sender = cleanSender(item.sender)
                let title = "\(item.code)   \(sender.isEmpty ? "پیامک" : sender) · \(ago(item.at))"
                let mi = NSMenuItem(title: title, action: #selector(copyMenuItem(_:)), keyEquivalent: "")
                mi.target = self
                mi.representedObject = item.code
                menu.addItem(mi)
            }
        }
        menu.addItem(NSMenuItem.separator())

        let sound = NSMenuItem(title: "صدای دریافت کد", action: #selector(toggleSound(_:)), keyEquivalent: "")
        sound.target = self
        sound.state = soundOn ? .on : .off
        menu.addItem(sound)

        if #available(macOS 13.0, *) {
            let login = NSMenuItem(title: "اجرا هنگام ورود به مک", action: #selector(toggleLogin(_:)), keyEquivalent: "")
            login.target = self
            login.state = SMAppService.mainApp.status == .enabled ? .on : .off
            menu.addItem(login)
        }

        let test = NSMenuItem(title: "نمایش پاپ‌آپ آخرین کد", action: #selector(showLatestPanel(_:)), keyEquivalent: "")
        test.target = self
        test.isEnabled = !items.isEmpty
        menu.addItem(test)

        let pair = NSMenuItem(title: "اتصال به حساب (خودکار)", action: #selector(openPairingItem(_:)), keyEquivalent: "")
        pair.target = self
        menu.addItem(pair)

        let settings = NSMenuItem(title: "تنظیمات…", action: #selector(openSettings(_:)), keyEquivalent: ",")
        settings.target = self
        menu.addItem(settings)

        let openBoard = NSMenuItem(title: "باز کردن تابلوی وب", action: #selector(openWeb(_:)), keyEquivalent: "")
        openBoard.target = self
        menu.addItem(openBoard)

        menu.addItem(NSMenuItem.separator())
        let quit = NSMenuItem(title: "خروج", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        menu.addItem(quit)
        return menu
    }

    @objc private func copyMenuItem(_ sender: NSMenuItem) {
        if let code = sender.representedObject as? String {
            copy(code)
        }
    }

    @objc private func toggleSound(_ sender: NSMenuItem) {
        defaults.set(!soundOn, forKey: "sound")
    }

    @objc private func toggleLogin(_ sender: NSMenuItem) {
        if #available(macOS 13.0, *) {
            do {
                if SMAppService.mainApp.status == .enabled {
                    try SMAppService.mainApp.unregister()
                } else {
                    try SMAppService.mainApp.register()
                }
            } catch {
                NSSound.beep()
            }
        }
    }

    @objc private func openSettings(_ sender: Any?) {
        promptSettings()
    }

    @objc private func openWeb(_ sender: Any?) {
        if let url = URL(string: "\(baseURL)/otp") {
            NSWorkspace.shared.open(url)
        }
    }

    // MARK: - Copy

    private func copyLatest() {
        guard let first = items.first else { return }
        copy(first.code)
    }

    private func copy(_ code: String) {
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.setString(code, forType: .string)
        flash("✓ \(code)")
        if soundOn { NSSound(named: "Pop")?.play() }
    }

    private func flash(_ text: String) {
        statusItem.button?.title = text
        flashTimer?.invalidate()
        flashTimer = Timer.scheduledTimer(withTimeInterval: 1.4, repeats: false) { [weak self] _ in
            self?.updateTitle()
        }
    }

    private func updateTitle() {
        guard let button = statusItem.button else { return }
        if let first = items.first {
            button.title = "🔑 \(first.code)"
        } else if lastError != nil {
            button.title = "🔑 !"
        } else {
            button.title = "🔑 —"
        }
    }

    // MARK: - Polling

    private func poll() {
        guard !token.isEmpty, let url = URL(string: "\(baseURL)/api/otp/recent?hours=24") else { return }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.timeoutInterval = 10
        req.cachePolicy = .reloadIgnoringLocalCacheData
        URLSession.shared.dataTask(with: req) { [weak self] data, response, error in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if let error = error {
                    self.lastError = "خطای شبکه: \(error.localizedDescription)"
                    self.updateTitle()
                    return
                }
                if let http = response as? HTTPURLResponse, http.statusCode != 200 {
                    self.lastError = http.statusCode == 401 ? "توکن نامعتبر — تنظیمات را چک کن" : "HTTP \(http.statusCode)"
                    self.updateTitle()
                    return
                }
                guard let data = data, let decoded = try? JSONDecoder().decode(OtpResponse.self, from: data) else {
                    self.lastError = "پاسخ نامعتبر از سرور"
                    self.updateTitle()
                    return
                }
                self.lastError = nil
                self.apply(decoded.items)
            }
        }.resume()
    }

    private func apply(_ fresh: [OtpItem]) {
        items = fresh
        if firstLoad {
            firstLoad = false
            for item in fresh { seen.insert(item.id) }
            updateTitle()
            return
        }
        let newOnes = fresh.filter { !seen.contains($0.id) }
        for item in newOnes { seen.insert(item.id) }
        updateTitle()
        if let top = newOnes.first {
            showPanel(for: top)
            notify(top)
            if soundOn { NSSound(named: "Glass")?.play() }
        }
    }

    // MARK: - Popup card

    private func buildPanelIfNeeded() {
        if panel != nil { return }
        let W: CGFloat = 460, H: CGFloat = 104
        let p = NSPanel(contentRect: NSRect(x: 0, y: 0, width: W, height: H),
                        styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        p.level = .statusBar
        p.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenAuxiliary]
        p.isOpaque = false
        p.backgroundColor = .clear
        p.hasShadow = true
        p.hidesOnDeactivate = false

        let root = ClickView(frame: NSRect(x: 0, y: 0, width: W, height: H))
        root.wantsLayer = true
        root.layer?.cornerRadius = 26
        root.layer?.masksToBounds = true
        root.layer?.backgroundColor = NSColor(calibratedWhite: 0.16, alpha: 0.96).cgColor
        root.onClick = { [weak self] in self?.panelCopy(nil) }

        let icon = NSImageView(frame: NSRect(x: 14, y: (H - 52) / 2, width: 52, height: 52))
        icon.image = NSApp.applicationIconImage
        icon.imageScaling = .scaleProportionallyUpOrDown
        root.addSubview(icon)

        let code = NSTextField(labelWithString: "")
        code.frame = NSRect(x: 78, y: 54, width: 250, height: 42)
        code.font = NSFont.monospacedDigitSystemFont(ofSize: 34, weight: .bold)
        code.textColor = .white
        code.lineBreakMode = .byClipping
        root.addSubview(code)
        panelCode = code

        let from = NSTextField(labelWithString: "")
        from.frame = NSRect(x: 78, y: 10, width: 250, height: 40)
        from.font = NSFont.systemFont(ofSize: 13)
        from.textColor = NSColor(calibratedWhite: 0.82, alpha: 1)
        from.lineBreakMode = .byWordWrapping
        from.maximumNumberOfLines = 2
        from.cell?.wraps = true
        from.cell?.truncatesLastVisibleLine = true
        root.addSubview(from)
        panelFrom = from

        let blue = NSColor(calibratedRed: 0.30, green: 0.45, blue: 1.0, alpha: 1)
        let copyBtn = panelButton(symbol: "doc.on.doc", fallback: "⧉", title: "Copy", color: blue, action: #selector(panelCopy(_:)))
        copyBtn.frame = NSRect(x: W - 118, y: 16, width: 64, height: 72)
        root.addSubview(copyBtn)
        let closeBtn = panelButton(symbol: "xmark.circle.fill", fallback: "✕", title: nil, color: NSColor(calibratedWhite: 0.62, alpha: 1), action: #selector(panelDelete(_:)))
        closeBtn.frame = NSRect(x: W - 46, y: (H - 36) / 2, width: 36, height: 36)
        root.addSubview(closeBtn)

        p.contentView = root
        panel = p
    }

    // Icon button (SF Symbol, large) with an optional caption under it.
    private func panelButton(symbol: String, fallback: String, title: String?, color: NSColor, action: Selector) -> NSButton {
        let b = NSButton(frame: .zero)
        b.isBordered = false
        b.target = self
        b.action = action
        var img: NSImage? = nil
        if #available(macOS 11.0, *) {
            img = NSImage(systemSymbolName: symbol, accessibilityDescription: title ?? symbol)
            let cfg = NSImage.SymbolConfiguration(pointSize: title == nil ? 18 : 26, weight: .medium)
            img = img?.withSymbolConfiguration(cfg)
        }
        if let img = img {
            b.image = img
            b.imagePosition = title == nil ? .imageOnly : .imageAbove
            b.contentTintColor = color
        }
        let ps = NSMutableParagraphStyle()
        ps.alignment = .center
        var label = title ?? (img == nil ? fallback : "")
        if img == nil, let t = title { label = "\(fallback)\n\(t)" }
        b.attributedTitle = NSAttributedString(string: label, attributes: [
            .foregroundColor: color,
            .font: NSFont.systemFont(ofSize: 15, weight: .medium),
            .paragraphStyle: ps,
        ])
        return b
    }

    private func showPanel(for item: OtpItem) {
        buildPanelIfNeeded()
        guard let p = panel else { return }
        panelCodeValue = item.code
        panelCode?.stringValue = item.code
        let sender = cleanSender(item.sender)
        var via = item.via ?? ""
        if via.hasPrefix("پیامک") { via = String(via.dropFirst(5)).trimmingCharacters(in: .whitespaces) }
        var line = "OTP from \(sender.isEmpty ? "SMS" : sender)"
        if !via.isEmpty { line += "\nاز \(via)" }
        panelFrom?.stringValue = line

        let vf = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
        var f = p.frame
        f.origin.x = vf.maxX - f.size.width - 14
        f.origin.y = vf.maxY - f.size.height - 12
        p.setFrame(f, display: true)
        p.alphaValue = 0
        p.orderFrontRegardless()
        NSAnimationContext.runAnimationGroup { ctx in
            ctx.duration = 0.22
            p.animator().alphaValue = 1
        }
        panelTimer?.invalidate()
        let secs = defaults.object(forKey: "panelSeconds") == nil ? 25 : defaults.integer(forKey: "panelSeconds")
        if secs > 0 {
            panelTimer = Timer.scheduledTimer(withTimeInterval: TimeInterval(secs), repeats: false) { [weak self] _ in
                self?.hidePanel()
            }
        }
    }

    private func hidePanel() {
        panelTimer?.invalidate()
        panelTimer = nil
        guard let p = panel else { return }
        NSAnimationContext.runAnimationGroup({ ctx in
            ctx.duration = 0.18
            p.animator().alphaValue = 0
        }, completionHandler: { p.orderOut(nil) })
    }

    @objc private func panelCopy(_ sender: Any?) {
        guard !panelCodeValue.isEmpty else { return }
        copy(panelCodeValue)
        panelCode?.stringValue = "✓ Copied"
        panelTimer?.invalidate()
        panelTimer = Timer.scheduledTimer(withTimeInterval: 0.8, repeats: false) { [weak self] _ in
            self?.hidePanel()
        }
    }

    @objc private func panelDelete(_ sender: Any?) { hidePanel() }

    @objc private func showLatestPanel(_ sender: Any?) {
        if let first = items.first { showPanel(for: first) }
    }

    // MARK: - Notifications

    private func notify(_ item: OtpItem) {
        let content = UNMutableNotificationContent()
        content.title = item.code
        let sender = cleanSender(item.sender)
        let via = item.via ?? ""
        content.body = "\(via.isEmpty ? "" : "از \(via) · ")\(sender.isEmpty ? "پیامک" : sender) — کلیک = کپی"
        content.categoryIdentifier = "otp"
        content.userInfo = ["code": item.code]
        let request = UNNotificationRequest(identifier: item.id, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request) { _ in }
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .list])
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        if let code = response.notification.request.content.userInfo["code"] as? String {
            copy(code)
        }
        completionHandler()
    }

    // MARK: - Settings

    private func promptSettings() {
        let alert = NSAlert()
        alert.messageText = "تنظیمات OtpBar"
        alert.informativeText = "«اتصال خودکار» پنل را باز می‌کند و کلید را خودش می‌گیرد. ورود دستی هم ممکن است."
        alert.addButton(withTitle: "ذخیره")
        alert.addButton(withTitle: "انصراف")
        alert.addButton(withTitle: "اتصال خودکار…")

        let view = NSView(frame: NSRect(x: 0, y: 0, width: 360, height: 64))
        let urlField = NSTextField(frame: NSRect(x: 0, y: 36, width: 360, height: 24))
        urlField.placeholderString = "https://bot.text.bz"
        urlField.stringValue = baseURL
        let tokenField = NSTextField(frame: NSRect(x: 0, y: 4, width: 360, height: 24))
        tokenField.placeholderString = "code feed token"
        tokenField.stringValue = token
        view.addSubview(urlField)
        view.addSubview(tokenField)
        alert.accessoryView = view

        NSApp.activate(ignoringOtherApps: true)
        let r = alert.runModal()
        if r == .alertThirdButtonReturn {
            openPairing()
            return
        }
        if r == .alertFirstButtonReturn {
            defaults.set(urlField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "baseURL")
            defaults.set(tokenField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "token")
            firstLoad = true
            seen.removeAll()
            poll()
        }
    }

    // MARK: - Helpers

    private func cleanSender(_ s: String?) -> String {
        guard var v = s else { return "" }
        for prefix in ["☎️", "📨", "📱"] {
            if v.hasPrefix(prefix) { v = String(v.dropFirst(prefix.count)) }
        }
        return v.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func ago(_ iso: String) -> String {
        guard let d = isoParser.date(from: iso) else { return "" }
        let s = max(0, Int(Date().timeIntervalSince(d)))
        if s < 60 { return fa("\(s) ثانیه پیش") }
        let m = s / 60
        if m < 60 { return fa("\(m) دقیقه پیش") }
        let h = m / 60
        if h < 24 { return fa("\(h) ساعت پیش") }
        return fa("\(h / 24) روز پیش")
    }

    private func fa(_ s: String) -> String {
        let digits = Array("۰۱۲۳۴۵۶۷۸۹")
        var out = ""
        for ch in s {
            if let v = ch.wholeNumberValue, ch.isASCII { out.append(digits[v]) } else { out.append(ch) }
        }
        return out
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
