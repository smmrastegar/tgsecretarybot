// OtpBar — macOS menu-bar app for tgsecretarybot's OTP board (Objective-C).
//
// Same behaviour as OtpBar.swift, but compiled with clang and no Clang
// modules, so it builds on a Command Line Tools install whose Swift
// module maps are broken ("redefinition of module 'SwiftBridging'").
//
// Newest code in the menu bar, click = copy, right-click = recent list,
// notification with a Copy button per new code, launch at login.

#import <Cocoa/Cocoa.h>
#import <UserNotifications/UserNotifications.h>
#import <ServiceManagement/ServiceManagement.h>

@interface AppDelegate : NSObject <NSApplicationDelegate, UNUserNotificationCenterDelegate>
@property (strong) NSStatusItem *statusItem;
@property (strong) NSArray<NSDictionary *> *items;
@property (strong) NSMutableSet<NSString *> *seen;
@property (assign) BOOL firstLoad;
@property (strong) NSTimer *timer;
@property (strong) NSTimer *flashTimer;
@property (strong) NSString *lastError;
@property (strong) NSISO8601DateFormatter *iso;
@end

@implementation AppDelegate

- (NSString *)baseURL {
    NSString *s = [[NSUserDefaults standardUserDefaults] stringForKey:@"baseURL"] ?: @"https://bot.text.bz";
    if ([s hasSuffix:@"/"]) s = [s substringToIndex:s.length - 1];
    return s;
}
- (NSString *)token {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"token"] ?: @"";
}
- (BOOL)soundOn {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    return [d objectForKey:@"sound"] == nil ? YES : [d boolForKey:@"sound"];
}

- (void)applicationDidFinishLaunching:(NSNotification *)note {
    [NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];
    self.items = @[];
    self.seen = [NSMutableSet set];
    self.firstLoad = YES;
    self.iso = [[NSISO8601DateFormatter alloc] init];
    self.iso.formatOptions = NSISO8601DateFormatWithInternetDateTime;

    self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
    NSStatusBarButton *button = self.statusItem.button;
    button.title = @"🔑 …";
    button.target = self;
    button.action = @selector(statusClicked:);
    [button sendActionOn:(NSEventMaskLeftMouseUp | NSEventMaskRightMouseUp)];
    button.toolTip = @"کلیک = کپی آخرین کد · راست‌کلیک = فهرست";

    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate = self;
    [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert | UNAuthorizationOptionSound)
                          completionHandler:^(BOOL granted, NSError *error) {}];
    UNNotificationAction *copy = [UNNotificationAction actionWithIdentifier:@"copy" title:@"Copy" options:0];
    UNNotificationCategory *cat = [UNNotificationCategory categoryWithIdentifier:@"otp" actions:@[copy]
                                                              intentIdentifiers:@[] options:0];
    [center setNotificationCategories:[NSSet setWithObject:cat]];

    // First launch: no token → open the pairing page; the server sends
    // the token back through otpbar://pair (see application:openURLs:).
    if (self.token.length == 0) [self openPairing];
    [self poll];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:4.0 target:self selector:@selector(poll)
                                                userInfo:nil repeats:YES];
}

- (void)application:(NSApplication *)application openURLs:(NSArray<NSURL *> *)urls {
    for (NSURL *u in urls) {
        if (![u.scheme isEqualToString:@"otpbar"]) continue;
        NSURLComponents *c = [NSURLComponents componentsWithURL:u resolvingAgainstBaseURL:NO];
        NSString *token = nil, *base = nil;
        for (NSURLQueryItem *q in c.queryItems) {
            if ([q.name isEqualToString:@"token"]) token = q.value;
            if ([q.name isEqualToString:@"base"]) base = q.value;
        }
        if (token.length == 0) continue;
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        [d setObject:token forKey:@"token"];
        if (base.length) [d setObject:base forKey:@"baseURL"];
        self.firstLoad = YES;
        [self.seen removeAllObjects];
        self.lastError = nil;
        [self flash:@"✓ وصل شد"];
        [self poll];
    }
}

- (void)openPairing {
    NSURL *u = [NSURL URLWithString:[self.baseURL stringByAppendingString:@"/otp/pair?auto=1"]];
    if (u) [[NSWorkspace sharedWorkspace] openURL:u];
}

#pragma mark - Status item

- (void)statusClicked:(id)sender {
    NSEvent *e = [NSApp currentEvent];
    BOOL isRight = (e.type == NSEventTypeRightMouseUp) || ((e.modifierFlags & NSEventModifierFlagControl) != 0);
    if (isRight || self.items.count == 0) {
        [self showMenu];
    } else {
        [self copyLatest];
    }
}

- (void)showMenu {
    NSMenu *menu = [self buildMenu];
    self.statusItem.menu = menu;
    [self.statusItem.button performClick:nil];
    self.statusItem.menu = nil;
}

- (NSMenu *)buildMenu {
    NSMenu *menu = [[NSMenu alloc] init];
    if (self.items.count == 0) {
        NSMenuItem *empty = [[NSMenuItem alloc] initWithTitle:(self.lastError ?: @"هنوز کدی نیامده") action:nil keyEquivalent:@""];
        empty.enabled = NO;
        [menu addItem:empty];
    } else {
        NSMenuItem *header = [[NSMenuItem alloc] initWithTitle:@"کدهای اخیر — کلیک = کپی" action:nil keyEquivalent:@""];
        header.enabled = NO;
        [menu addItem:header];
        NSUInteger n = MIN(self.items.count, (NSUInteger)12);
        for (NSUInteger i = 0; i < n; i++) {
            NSDictionary *it = self.items[i];
            NSString *code = it[@"code"];
            NSString *sender = [self cleanSender:it[@"sender"]];
            NSString *title = [NSString stringWithFormat:@"%@   %@ · %@", code,
                               sender.length ? sender : @"پیامک", [self ago:it[@"at"]]];
            NSMenuItem *mi = [[NSMenuItem alloc] initWithTitle:title action:@selector(copyMenuItem:) keyEquivalent:@""];
            mi.target = self;
            mi.representedObject = code;
            [menu addItem:mi];
        }
    }
    [menu addItem:[NSMenuItem separatorItem]];

    NSMenuItem *sound = [[NSMenuItem alloc] initWithTitle:@"صدای دریافت کد" action:@selector(toggleSound:) keyEquivalent:@""];
    sound.target = self;
    sound.state = self.soundOn ? NSControlStateValueOn : NSControlStateValueOff;
    [menu addItem:sound];

    if (@available(macOS 13.0, *)) {
        NSMenuItem *login = [[NSMenuItem alloc] initWithTitle:@"اجرا هنگام ورود به مک" action:@selector(toggleLogin:) keyEquivalent:@""];
        login.target = self;
        login.state = ([SMAppService mainAppService].status == SMAppServiceStatusEnabled) ? NSControlStateValueOn : NSControlStateValueOff;
        [menu addItem:login];
    }

    NSMenuItem *pair = [[NSMenuItem alloc] initWithTitle:@"اتصال به حساب (خودکار)" action:@selector(openPairingItem:) keyEquivalent:@""];
    pair.target = self;
    [menu addItem:pair];

    NSMenuItem *settings = [[NSMenuItem alloc] initWithTitle:@"تنظیمات…" action:@selector(openSettings:) keyEquivalent:@","];
    settings.target = self;
    [menu addItem:settings];

    NSMenuItem *web = [[NSMenuItem alloc] initWithTitle:@"باز کردن تابلوی وب" action:@selector(openWeb:) keyEquivalent:@""];
    web.target = self;
    [menu addItem:web];

    [menu addItem:[NSMenuItem separatorItem]];
    NSMenuItem *quit = [[NSMenuItem alloc] initWithTitle:@"خروج" action:@selector(terminate:) keyEquivalent:@"q"];
    quit.target = NSApp;
    [menu addItem:quit];
    return menu;
}

- (void)copyMenuItem:(NSMenuItem *)sender {
    NSString *code = sender.representedObject;
    if ([code isKindOfClass:[NSString class]]) [self copyCode:code];
}

- (void)toggleSound:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:!self.soundOn forKey:@"sound"];
}

- (void)toggleLogin:(id)sender {
    if (@available(macOS 13.0, *)) {
        NSError *err = nil;
        SMAppService *svc = [SMAppService mainAppService];
        if (svc.status == SMAppServiceStatusEnabled) {
            [svc unregisterAndReturnError:&err];
        } else {
            [svc registerAndReturnError:&err];
        }
        if (err) NSBeep();
    }
}

- (void)openSettings:(id)sender { [self promptSettings]; }
- (void)openPairingItem:(id)sender { [self openPairing]; }

- (void)openWeb:(id)sender {
    NSURL *u = [NSURL URLWithString:[self.baseURL stringByAppendingString:@"/otp"]];
    if (u) [[NSWorkspace sharedWorkspace] openURL:u];
}

#pragma mark - Copy

- (void)copyLatest {
    if (self.items.count == 0) return;
    [self copyCode:self.items[0][@"code"]];
}

- (void)copyCode:(NSString *)code {
    NSPasteboard *pb = [NSPasteboard generalPasteboard];
    [pb clearContents];
    [pb setString:code forType:NSPasteboardTypeString];
    [self flash:[NSString stringWithFormat:@"✓ %@", code]];
    if (self.soundOn) [[NSSound soundNamed:@"Pop"] play];
}

- (void)flash:(NSString *)text {
    self.statusItem.button.title = text;
    [self.flashTimer invalidate];
    self.flashTimer = [NSTimer scheduledTimerWithTimeInterval:1.4 target:self selector:@selector(updateTitle)
                                                     userInfo:nil repeats:NO];
}

- (void)updateTitle {
    NSStatusBarButton *button = self.statusItem.button;
    if (self.items.count > 0) {
        button.title = [NSString stringWithFormat:@"🔑 %@", self.items[0][@"code"]];
    } else if (self.lastError) {
        button.title = @"🔑 !";
    } else {
        button.title = @"🔑 —";
    }
}

#pragma mark - Polling

- (void)poll {
    NSString *token = self.token;
    if (token.length == 0) return;
    NSURL *url = [NSURL URLWithString:[self.baseURL stringByAppendingString:@"/api/otp/recent?hours=24"]];
    if (!url) return;
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    [req setValue:[@"Bearer " stringByAppendingString:token] forHTTPHeaderField:@"Authorization"];
    req.timeoutInterval = 10;
    req.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    __weak typeof(self) weakSelf = self;
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) strongSelf = weakSelf;
            if (!strongSelf) return;
            if (error) {
                strongSelf.lastError = [NSString stringWithFormat:@"خطای شبکه: %@", error.localizedDescription];
                [strongSelf updateTitle];
                return;
            }
            NSInteger status = [(NSHTTPURLResponse *)response statusCode];
            if (status != 200) {
                strongSelf.lastError = status == 401 ? @"توکن نامعتبر — تنظیمات را چک کن"
                                                     : [NSString stringWithFormat:@"HTTP %ld", (long)status];
                [strongSelf updateTitle];
                return;
            }
            NSDictionary *json = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            NSArray *items = [json isKindOfClass:[NSDictionary class]] ? json[@"items"] : nil;
            if (![items isKindOfClass:[NSArray class]]) {
                strongSelf.lastError = @"پاسخ نامعتبر از سرور";
                [strongSelf updateTitle];
                return;
            }
            strongSelf.lastError = nil;
            [strongSelf apply:items];
        });
    }] resume];
}

- (void)apply:(NSArray *)fresh {
    NSMutableArray *clean = [NSMutableArray array];
    for (id it in fresh) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        if (![it[@"id"] isKindOfClass:[NSString class]] || ![it[@"code"] isKindOfClass:[NSString class]]) continue;
        [clean addObject:it];
    }
    self.items = clean;
    if (self.firstLoad) {
        self.firstLoad = NO;
        for (NSDictionary *it in clean) [self.seen addObject:it[@"id"]];
        [self updateTitle];
        return;
    }
    NSMutableArray *newOnes = [NSMutableArray array];
    for (NSDictionary *it in clean) {
        if (![self.seen containsObject:it[@"id"]]) {
            [self.seen addObject:it[@"id"]];
            [newOnes addObject:it];
        }
    }
    [self updateTitle];
    if (newOnes.count > 0) {
        [self notify:newOnes[0]];
        if (self.soundOn) [[NSSound soundNamed:@"Glass"] play];
    }
}

#pragma mark - Notifications

- (void)notify:(NSDictionary *)item {
    UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc] init];
    NSString *code = item[@"code"];
    NSString *sender = [self cleanSender:item[@"sender"]];
    content.title = code;
    content.body = [NSString stringWithFormat:@"کد از %@ — کلیک = کپی", sender.length ? sender : @"پیامک"];
    content.categoryIdentifier = @"otp";
    content.userInfo = @{@"code": code};
    UNNotificationRequest *req = [UNNotificationRequest requestWithIdentifier:item[@"id"] content:content trigger:nil];
    [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:req withCompletionHandler:^(NSError *error) {}];
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center
       willPresentNotification:(UNNotification *)notification
         withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler {
    if (@available(macOS 11.0, *)) {
        completionHandler(UNNotificationPresentationOptionBanner | UNNotificationPresentationOptionList);
    } else {
        completionHandler(UNNotificationPresentationOptionAlert);
    }
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center
didReceiveNotificationResponse:(UNNotificationResponse *)response
         withCompletionHandler:(void (^)(void))completionHandler {
    NSString *code = response.notification.request.content.userInfo[@"code"];
    if ([code isKindOfClass:[NSString class]]) [self copyCode:code];
    completionHandler();
}

#pragma mark - Settings

- (void)promptSettings {
    NSAlert *alert = [[NSAlert alloc] init];
    alert.messageText = @"تنظیمات OtpBar";
    alert.informativeText = @"«اتصال خودکار» پنل را باز می‌کند و کلید را خودش می‌گیرد. ورود دستی هم ممکن است.";
    [alert addButtonWithTitle:@"ذخیره"];
    [alert addButtonWithTitle:@"انصراف"];
    [alert addButtonWithTitle:@"اتصال خودکار…"];

    NSView *view = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 360, 64)];
    NSTextField *urlField = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 36, 360, 24)];
    urlField.placeholderString = @"https://bot.text.bz";
    urlField.stringValue = self.baseURL;
    NSTextField *tokenField = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 4, 360, 24)];
    tokenField.placeholderString = @"code feed token";
    tokenField.stringValue = self.token;
    [view addSubview:urlField];
    [view addSubview:tokenField];
    alert.accessoryView = view;

    [NSApp activateIgnoringOtherApps:YES];
    NSModalResponse r = [alert runModal];
    if (r == NSAlertThirdButtonReturn) {
        [self openPairing];
        return;
    }
    if (r == NSAlertFirstButtonReturn) {
        NSCharacterSet *ws = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        [d setObject:[urlField.stringValue stringByTrimmingCharactersInSet:ws] forKey:@"baseURL"];
        [d setObject:[tokenField.stringValue stringByTrimmingCharactersInSet:ws] forKey:@"token"];
        self.firstLoad = YES;
        [self.seen removeAllObjects];
        [self poll];
    }
}

#pragma mark - Helpers

- (NSString *)cleanSender:(id)s {
    if (![s isKindOfClass:[NSString class]]) return @"";
    NSString *v = s;
    for (NSString *prefix in @[@"☎️", @"📨", @"📱"]) {
        if ([v hasPrefix:prefix]) v = [v substringFromIndex:prefix.length];
    }
    return [v stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *)ago:(id)iso {
    if (![iso isKindOfClass:[NSString class]]) return @"";
    NSDate *d = [self.iso dateFromString:iso];
    if (!d) return @"";
    NSInteger s = MAX(0, (NSInteger)[[NSDate date] timeIntervalSinceDate:d]);
    if (s < 60) return [self fa:[NSString stringWithFormat:@"%ld ثانیه پیش", (long)s]];
    NSInteger m = s / 60;
    if (m < 60) return [self fa:[NSString stringWithFormat:@"%ld دقیقه پیش", (long)m]];
    NSInteger h = m / 60;
    if (h < 24) return [self fa:[NSString stringWithFormat:@"%ld ساعت پیش", (long)h]];
    return [self fa:[NSString stringWithFormat:@"%ld روز پیش", (long)(h / 24)]];
}

- (NSString *)fa:(NSString *)s {
    NSArray *digits = @[@"۰", @"۱", @"۲", @"۳", @"۴", @"۵", @"۶", @"۷", @"۸", @"۹"];
    NSMutableString *out = [NSMutableString string];
    for (NSUInteger i = 0; i < s.length; i++) {
        unichar c = [s characterAtIndex:i];
        if (c >= '0' && c <= '9') [out appendString:digits[c - '0']];
        else [out appendFormat:@"%C", c];
    }
    return out;
}

@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSApplication *app = [NSApplication sharedApplication];
        AppDelegate *delegate = [[AppDelegate alloc] init];
        app.delegate = delegate;
        [app run];
    }
    return 0;
}
