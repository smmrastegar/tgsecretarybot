// OtpBar — macOS menu-bar app for tgsecretarybot's OTP board (Objective-C).
//
// Same behaviour as OtpBar.swift, but compiled with clang and no Clang
// modules, so it builds on a Command Line Tools install whose Swift
// module maps are broken ("redefinition of module 'SwiftBridging'").
//
// Newest code in the menu bar, click = copy, right-click = recent list,
// notification with a Copy button per new code, launch at login.

#import <Cocoa/Cocoa.h>
#import <UserNotifications/UserNotifications.h>
#import <ServiceManagement/ServiceManagement.h>

// A view whose whole area is a click target (the popup card: tap anywhere = copy).
@interface ClickView : NSView
@property (copy) void (^onClick)(void);
@end
@implementation ClickView
- (void)mouseDown:(NSEvent *)event { if (self.onClick) self.onClick(); }
@end

@interface AppDelegate : NSObject <NSApplicationDelegate, UNUserNotificationCenterDelegate>
@property (strong) NSPanel *panel;
@property (strong) NSTextField *panelCode;
@property (strong) NSTextField *panelFrom;
@property (strong) NSTimer *panelTimer;
@property (strong) NSString *panelCodeValue;
@property (strong) NSStatusItem *statusItem;
@property (strong) NSArray<NSDictionary *> *items;
@property (strong) NSMutableSet<NSString *> *seen;
@property (assign) BOOL firstLoad;
@property (strong) NSTimer *timer;
@property (strong) NSTimer *flashTimer;
@property (strong) NSString *lastError;
@property (strong) NSISO8601DateFormatter *iso;
@end

@implementation AppDelegate

- (NSString *)baseURL {
    NSString *s = [[NSUserDefaults standardUserDefaults] stringForKey:@"baseURL"] ?: @"https://bot.text.bz";
    if ([s hasSuffix:@"/"]) s = [s substringToIndex:s.length - 1];
    return s;
}
- (NSString *)token {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"token"] ?: @"";
}
- (BOOL)soundOn {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    return [d objectForKey:@"sound"] == nil ? YES : [d boolForKey:@"sound"];
}

- (void)applicationDidFinishLaunching:(NSNotification *)note {
    [NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];
    self.items = @[];
    self.seen = [NSMutableSet set];
    self.firstLoad = YES;
    self.iso = [[NSISO8601DateFormatter alloc] init];
    self.iso.formatOptions = NSISO8601DateFormatWithInternetDateTime;

    self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
    NSStatusBarButton *button = self.statusItem.button;
    button.title = @"🔑 …";
    button.target = self;
    button.action = @selector(statusClicked:);
    [button sendActionOn:(NSEventMaskLeftMouseUp | NSEventMaskRightMouseUp)];
    button.toolTip = @"کلیک = کپی آخرین کد · راست‌کلیک = فهرست";

    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate = self;
    [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert | UNAuthorizationOptionSound)
                          completionHandler:^(BOOL granted, NSError *error) {}];
    UNNotificationAction *copy = [UNNotificationAction actionWithIdentifier:@"copy" title:@"Copy" options:0];
    UNNotificationCategory *cat = [UNNotificationCategory categoryWithIdentifier:@"otp" actions:@[copy]
                                                              intentIdentifiers:@[] options:0];
    [center setNotificationCategories:[NSSet setWithObject:cat]];

    // First launch: no token → open the pairing page; the server sends
    // the token back through otpbar://pair (see application:openURLs:).
    if (self.token.length == 0) [self openPairing];
    [self poll];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:4.0 target:self selector:@selector(poll)
                                                userInfo:nil repeats:YES];
}

- (void)application:(NSApplication *)application openURLs:(NSArray<NSURL *> *)urls {
    for (NSURL *u in urls) {
        if (![u.scheme isEqualToString:@"otpbar"]) continue;
        NSURLComponents *c = [NSURLComponents componentsWithURL:u resolvingAgainstBaseURL:NO];
        NSString *token = nil, *base = nil;
        for (NSURLQueryItem *q in c.queryItems) {
            if ([q.name isEqualToString:@"token"]) token = q.value;
            if ([q.name isEqualToString:@"base"]) base = q.value;
        }
        if (token.length == 0) continue;
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        [d setObject:token forKey:@"token"];
        if (base.length) [d setObject:base forKey:@"baseURL"];
        self.firstLoad = YES;
        [self.seen removeAllObjects];
        self.lastError = nil;
        [self flash:@"✓ وصل شد"];
        [self poll];
    }
}

- (void)openPairing {
    NSURL *u = [NSURL URLWithString:[self.baseURL stringByAppendingString:@"/otp/pair?auto=1"]];
    if (u) [[NSWorkspace sharedWorkspace] openURL:u];
}

#pragma mark - Status item

- (void)statusClicked:(id)sender {
    NSEvent *e = [NSApp currentEvent];
    BOOL isRight = (e.type == NSEventTypeRightMouseUp) || ((e.modifierFlags & NSEventModifierFlagControl) != 0);
    if (isRight || self.items.count == 0) {
        [self showMenu];
    } else {
        [self copyLatest];
    }
}

- (void)showMenu {
    NSMenu *menu = [self buildMenu];
    self.statusItem.menu = menu;
    [self.statusItem.button performClick:nil];
    self.statusItem.menu = nil;
}

- (NSMenu *)buildMenu {
    NSMenu *menu = [[NSMenu alloc] init];
    if (self.items.count == 0) {
        NSMenuItem *empty = [[NSMenuItem alloc] initWithTitle:(self.lastError ?: @"هنوز کدی نیامده") action:nil keyEquivalent:@""];
        empty.enabled = NO;
        [menu addItem:empty];
    } else {
        NSMenuItem *header = [[NSMenuItem alloc] initWithTitle:@"کدهای اخیر — کلیک = کپی" action:nil keyEquivalent:@""];
        header.enabled = NO;
        [menu addItem:header];
        NSUInteger n = MIN(self.items.count, (NSUInteger)12);
        for (NSUInteger i = 0; i < n; i++) {
            NSDictionary *it = self.items[i];
            NSString *code = it[@"code"];
            NSString *sender = [self cleanSender:it[@"sender"]];
            NSString *title = [NSString stringWithFormat:@"%@   %@ · %@", code,
                               sender.length ? sender : @"پیامک", [self ago:it[@"at"]]];
            NSMenuItem *mi = [[NSMenuItem alloc] initWithTitle:title action:@selector(copyMenuItem:) keyEquivalent:@""];
            mi.target = self;
            mi.representedObject = code;
            [menu addItem:mi];
        }
    }
    [menu addItem:[NSMenuItem separatorItem]];

    NSMenuItem *sound = [[NSMenuItem alloc] initWithTitle:@"صدای دریافت کد" action:@selector(toggleSound:) keyEquivalent:@""];
    sound.target = self;
    sound.state = self.soundOn ? NSControlStateValueOn : NSControlStateValueOff;
    [menu addItem:sound];

    if (@available(macOS 13.0, *)) {
        NSMenuItem *login = [[NSMenuItem alloc] initWithTitle:@"اجرا هنگام ورود به مک" action:@selector(toggleLogin:) keyEquivalent:@""];
        login.target = self;
        login.state = ([SMAppService mainAppService].status == SMAppServiceStatusEnabled) ? NSControlStateValueOn : NSControlStateValueOff;
        [menu addItem:login];
    }

    NSMenuItem *test = [[NSMenuItem alloc] initWithTitle:@"نمایش پاپ‌آپ آخرین کد" action:@selector(showLatestPanel:) keyEquivalent:@""];
    test.target = self;
    test.enabled = self.items.count > 0;
    [menu addItem:test];

    NSMenuItem *pair = [[NSMenuItem alloc] initWithTitle:@"اتصال به حساب (خودکار)" action:@selector(openPairingItem:) keyEquivalent:@""];
    pair.target = self;
    [menu addItem:pair];

    NSMenuItem *settings = [[NSMenuItem alloc] initWithTitle:@"تنظیمات…" action:@selector(openSettings:) keyEquivalent:@","];
    settings.target = self;
    [menu addItem:settings];

    NSMenuItem *web = [[NSMenuItem alloc] initWithTitle:@"باز کردن تابلوی وب" action:@selector(openWeb:) keyEquivalent:@""];
    web.target = self;
    [menu addItem:web];

    [menu addItem:[NSMenuItem separatorItem]];
    NSMenuItem *quit = [[NSMenuItem alloc] initWithTitle:@"خروج" action:@selector(terminate:) keyEquivalent:@"q"];
    quit.target = NSApp;
    [menu addItem:quit];
    return menu;
}

- (void)copyMenuItem:(NSMenuItem *)sender {
    NSString *code = sender.representedObject;
    if ([code isKindOfClass:[NSString class]]) [self copyCode:code];
}

- (void)toggleSound:(id)sender {
    [[NSUserDefaults standardUserDefaults] setBool:!self.soundOn forKey:@"sound"];
}

- (void)toggleLogin:(id)sender {
    if (@available(macOS 13.0, *)) {
        NSError *err = nil;
        SMAppService *svc = [SMAppService mainAppService];
        if (svc.status == SMAppServiceStatusEnabled) {
            [svc unregisterAndReturnError:&err];
        } else {
            [svc registerAndReturnError:&err];
        }
        if (err) NSBeep();
    }
}

- (void)openSettings:(id)sender { [self promptSettings]; }
- (void)openPairingItem:(id)sender { [self openPairing]; }

- (void)openWeb:(id)sender {
    NSURL *u = [NSURL URLWithString:[self.baseURL stringByAppendingString:@"/otp"]];
    if (u) [[NSWorkspace sharedWorkspace] openURL:u];
}

#pragma mark - Copy

- (void)copyLatest {
    if (self.items.count == 0) return;
    [self copyCode:self.items[0][@"code"]];
}

- (void)copyCode:(NSString *)code {
    NSPasteboard *pb = [NSPasteboard generalPasteboard];
    [pb clearContents];
    [pb setString:code forType:NSPasteboardTypeString];
    [self flash:[NSString stringWithFormat:@"✓ %@", code]];
    if (self.soundOn) [[NSSound soundNamed:@"Pop"] play];
}

- (void)flash:(NSString *)text {
    self.statusItem.button.title = text;
    [self.flashTimer invalidate];
    self.flashTimer = [NSTimer scheduledTimerWithTimeInterval:1.4 target:self selector:@selector(updateTitle)
                                                     userInfo:nil repeats:NO];
}

- (void)updateTitle {
    NSStatusBarButton *button = self.statusItem.button;
    if (self.items.count > 0) {
        button.title = [NSString stringWithFormat:@"🔑 %@", self.items[0][@"code"]];
    } else if (self.lastError) {
        button.title = @"🔑 !";
    } else {
        button.title = @"🔑 —";
    }
}

#pragma mark - Polling

- (void)poll {
    NSString *token = self.token;
    if (token.length == 0) return;
    NSURL *url = [NSURL URLWithString:[self.baseURL stringByAppendingString:@"/api/otp/recent?hours=24"]];
    if (!url) return;
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    [req setValue:[@"Bearer " stringByAppendingString:token] forHTTPHeaderField:@"Authorization"];
    req.timeoutInterval = 10;
    req.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    __weak typeof(self) weakSelf = self;
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) strongSelf = weakSelf;
            if (!strongSelf) return;
            if (error) {
                strongSelf.lastError = [NSString stringWithFormat:@"خطای شبکه: %@", error.localizedDescription];
                [strongSelf updateTitle];
                return;
            }
            NSInteger status = [(NSHTTPURLResponse *)response statusCode];
            if (status != 200) {
                strongSelf.lastError = status == 401 ? @"توکن نامعتبر — تنظیمات را چک کن"
                                                     : [NSString stringWithFormat:@"HTTP %ld", (long)status];
                [strongSelf updateTitle];
                return;
            }
            NSDictionary *json = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            NSArray *items = [json isKindOfClass:[NSDictionary class]] ? json[@"items"] : nil;
            if (![items isKindOfClass:[NSArray class]]) {
                strongSelf.lastError = @"پاسخ نامعتبر از سرور";
                [strongSelf updateTitle];
                return;
            }
            strongSelf.lastError = nil;
            [strongSelf apply:items];
        });
    }] resume];
}

- (void)apply:(NSArray *)fresh {
    NSMutableArray *clean = [NSMutableArray array];
    for (id it in fresh) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        if (![it[@"id"] isKindOfClass:[NSString class]] || ![it[@"code"] isKindOfClass:[NSString class]]) continue;
        [clean addObject:it];
    }
    self.items = clean;
    if (self.firstLoad) {
        self.firstLoad = NO;
        for (NSDictionary *it in clean) [self.seen addObject:it[@"id"]];
        [self updateTitle];
        return;
    }
    NSMutableArray *newOnes = [NSMutableArray array];
    for (NSDictionary *it in clean) {
        if (![self.seen containsObject:it[@"id"]]) {
            [self.seen addObject:it[@"id"]];
            [newOnes addObject:it];
        }
    }
    [self updateTitle];
    if (newOnes.count > 0) {
        [self showPanelFor:newOnes[0]];
        [self notify:newOnes[0]];
        if (self.soundOn) [[NSSound soundNamed:@"Glass"] play];
    }
}

#pragma mark - Popup card

// The heads-up card: app icon, the code in large type, "OTP from <sender>
// · از <whose phone>", Copy / Delete. Floats above everything at the
// top-right of the main screen, never steals focus, hides itself after
// a while. Click anywhere on it = copy.
- (void)buildPanelIfNeeded {
    if (self.panel) return;
    CGFloat W = 440, H = 88;
    NSPanel *panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0, 0, W, H)
                                                styleMask:(NSWindowStyleMaskBorderless | NSWindowStyleMaskNonactivatingPanel)
                                                  backing:NSBackingStoreBuffered defer:NO];
    panel.level = NSStatusWindowLevel;
    panel.collectionBehavior = NSWindowCollectionBehaviorCanJoinAllSpaces | NSWindowCollectionBehaviorStationary | NSWindowCollectionBehaviorFullScreenAuxiliary;
    panel.opaque = NO;
    panel.backgroundColor = [NSColor clearColor];
    panel.hasShadow = YES;
    panel.hidesOnDeactivate = NO;
    panel.movableByWindowBackground = NO;

    ClickView *root = [[ClickView alloc] initWithFrame:NSMakeRect(0, 0, W, H)];
    root.wantsLayer = YES;
    root.layer.cornerRadius = 26;
    root.layer.masksToBounds = YES;
    root.layer.backgroundColor = [[NSColor colorWithCalibratedWhite:0.16 alpha:0.96] CGColor];
    __weak typeof(self) weakSelf = self;
    root.onClick = ^{ [weakSelf panelCopy:nil]; };

    NSImageView *icon = [[NSImageView alloc] initWithFrame:NSMakeRect(14, (H - 52) / 2, 52, 52)];
    icon.image = [NSApp applicationIconImage];
    icon.imageScaling = NSImageScaleProportionallyUpOrDown;
    [root addSubview:icon];

    NSTextField *code = [NSTextField labelWithString:@""];
    code.frame = NSMakeRect(78, 40, 210, 40);
    code.font = [NSFont monospacedDigitSystemFontOfSize:34 weight:NSFontWeightBold];
    code.textColor = [NSColor whiteColor];
    code.lineBreakMode = NSLineBreakByClipping;
    [root addSubview:code];
    self.panelCode = code;

    NSTextField *from = [NSTextField labelWithString:@""];
    from.frame = NSMakeRect(78, 12, 210, 22);
    from.font = [NSFont systemFontOfSize:14];
    from.textColor = [NSColor colorWithCalibratedWhite:0.82 alpha:1];
    from.lineBreakMode = NSLineBreakByTruncatingTail;
    [root addSubview:from];
    self.panelFrom = from;

    NSColor *blue = [NSColor colorWithCalibratedRed:0.30 green:0.45 blue:1.0 alpha:1];
    NSButton *copyBtn = [self panelButtonWithSymbol:@"doc.on.doc" fallback:@"⧉" title:@"Copy" color:blue action:@selector(panelCopy:)];
    copyBtn.frame = NSMakeRect(W - 156, 8, 76, 72);
    [root addSubview:copyBtn];
    NSButton *closeBtn = [self panelButtonWithSymbol:@"xmark.circle.fill" fallback:@"✕" title:nil color:[NSColor colorWithCalibratedWhite:0.75 alpha:1] action:@selector(panelDelete:)];
    closeBtn.frame = NSMakeRect(W - 74, 8, 60, 72);
    [root addSubview:closeBtn];

    panel.contentView = root;
    self.panel = panel;
}

// Icon button (SF Symbol, large) with an optional caption under it.
- (NSButton *)panelButtonWithSymbol:(NSString *)symbol fallback:(NSString *)fallback title:(NSString *)title
                              color:(NSColor *)color action:(SEL)action {
    NSButton *b = [[NSButton alloc] initWithFrame:NSZeroRect];
    b.bordered = NO;
    b.target = self;
    b.action = action;
    NSImage *img = nil;
    if (@available(macOS 11.0, *)) {
        img = [NSImage imageWithSystemSymbolName:symbol accessibilityDescription:title ?: symbol];
        NSImageSymbolConfiguration *cfg = [NSImageSymbolConfiguration configurationWithPointSize:(title ? 26 : 28) weight:NSFontWeightMedium];
        img = [img imageWithSymbolConfiguration:cfg];
    }
    if (img) {
        b.image = img;
        b.imagePosition = title ? NSImageAbove : NSImageOnly;
        if (@available(macOS 10.14, *)) b.contentTintColor = color;
    }
    NSMutableParagraphStyle *ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = NSTextAlignmentCenter;
    NSString *label = title ?: (img ? @"" : fallback);
    if (!img && title) label = [NSString stringWithFormat:@"%@\n%@", fallback, title];
    b.attributedTitle = [[NSAttributedString alloc] initWithString:label attributes:@{
        NSForegroundColorAttributeName: color,
        NSFontAttributeName: [NSFont systemFontOfSize:15 weight:NSFontWeightMedium],
        NSParagraphStyleAttributeName: ps,
    }];
    return b;
}

- (void)showPanelFor:(NSDictionary *)item {
    [self buildPanelIfNeeded];
    NSString *code = item[@"code"];
    self.panelCodeValue = code;
    self.panelCode.stringValue = code;
    NSString *sender = [self cleanSender:item[@"sender"]];
    NSString *via = [item[@"via"] isKindOfClass:[NSString class]] ? item[@"via"] : @"";
    if ([via hasPrefix:@"پیامک"]) via = [[via substringFromIndex:5] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *line = [NSString stringWithFormat:@"OTP from %@", sender.length ? sender : @"SMS"];
    if (via.length) line = [line stringByAppendingFormat:@"  ·  از %@", via];
    self.panelFrom.stringValue = line;

    NSRect vf = [NSScreen mainScreen].visibleFrame;
    NSRect f = self.panel.frame;
    f.origin.x = NSMaxX(vf) - f.size.width - 14;
    f.origin.y = NSMaxY(vf) - f.size.height - 12;
    [self.panel setFrame:f display:YES];
    self.panel.alphaValue = 0;
    [self.panel orderFrontRegardless];
    [NSAnimationContext runAnimationGroup:^(NSAnimationContext *ctx) {
        ctx.duration = 0.22;
        self.panel.animator.alphaValue = 1;
    } completionHandler:nil];

    [self.panelTimer invalidate];
    NSInteger secs = [[NSUserDefaults standardUserDefaults] objectForKey:@"panelSeconds"] ? [[NSUserDefaults standardUserDefaults] integerForKey:@"panelSeconds"] : 25;
    if (secs > 0) {
        self.panelTimer = [NSTimer scheduledTimerWithTimeInterval:secs target:self selector:@selector(hidePanel)
                                                         userInfo:nil repeats:NO];
    }
}

- (void)hidePanel {
    [self.panelTimer invalidate];
    self.panelTimer = nil;
    if (!self.panel) return;
    [NSAnimationContext runAnimationGroup:^(NSAnimationContext *ctx) {
        ctx.duration = 0.18;
        self.panel.animator.alphaValue = 0;
    } completionHandler:^{ [self.panel orderOut:nil]; }];
}

- (void)panelCopy:(id)sender {
    if (self.panelCodeValue.length == 0) return;
    [self copyCode:self.panelCodeValue];
    self.panelCode.stringValue = @"✓ Copied";
    [self.panelTimer invalidate];
    self.panelTimer = [NSTimer scheduledTimerWithTimeInterval:0.8 target:self selector:@selector(hidePanel)
                                                     userInfo:nil repeats:NO];
}

- (void)panelDelete:(id)sender { [self hidePanel]; }

- (void)showLatestPanel:(id)sender {
    if (self.items.count > 0) [self showPanelFor:self.items[0]];
}

#pragma mark - Notifications

- (void)notify:(NSDictionary *)item {
    UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc] init];
    NSString *code = item[@"code"];
    NSString *sender = [self cleanSender:item[@"sender"]];
    content.title = code;
    NSString *via = [item[@"via"] isKindOfClass:[NSString class]] ? item[@"via"] : @"";
    content.body = [NSString stringWithFormat:@"%@%@ — کلیک = کپی", via.length ? [NSString stringWithFormat:@"از %@ · ", via] : @"", sender.length ? sender : @"پیامک"];
    content.categoryIdentifier = @"otp";
    content.userInfo = @{@"code": code};
    UNNotificationRequest *req = [UNNotificationRequest requestWithIdentifier:item[@"id"] content:content trigger:nil];
    [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:req withCompletionHandler:^(NSError *error) {}];
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center
       willPresentNotification:(UNNotification *)notification
         withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler {
    if (@available(macOS 11.0, *)) {
        completionHandler(UNNotificationPresentationOptionBanner | UNNotificationPresentationOptionList);
    } else {
        completionHandler(UNNotificationPresentationOptionAlert);
    }
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center
didReceiveNotificationResponse:(UNNotificationResponse *)response
         withCompletionHandler:(void (^)(void))completionHandler {
    NSString *code = response.notification.request.content.userInfo[@"code"];
    if ([code isKindOfClass:[NSString class]]) [self copyCode:code];
    completionHandler();
}

#pragma mark - Settings

- (void)promptSettings {
    NSAlert *alert = [[NSAlert alloc] init];
    alert.messageText = @"تنظیمات OtpBar";
    alert.informativeText = @"«اتصال خودکار» پنل را باز می‌کند و کلید را خودش می‌گیرد. ورود دستی هم ممکن است.";
    [alert addButtonWithTitle:@"ذخیره"];
    [alert addButtonWithTitle:@"انصراف"];
    [alert addButtonWithTitle:@"اتصال خودکار…"];

    NSView *view = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 360, 64)];
    NSTextField *urlField = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 36, 360, 24)];
    urlField.placeholderString = @"https://bot.text.bz";
    urlField.stringValue = self.baseURL;
    NSTextField *tokenField = [[NSTextField alloc] initWithFrame:NSMakeRect(0, 4, 360, 24)];
    tokenField.placeholderString = @"code feed token";
    tokenField.stringValue = self.token;
    [view addSubview:urlField];
    [view addSubview:tokenField];
    alert.accessoryView = view;

    [NSApp activateIgnoringOtherApps:YES];
    NSModalResponse r = [alert runModal];
    if (r == NSAlertThirdButtonReturn) {
        [self openPairing];
        return;
    }
    if (r == NSAlertFirstButtonReturn) {
        NSCharacterSet *ws = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        [d setObject:[urlField.stringValue stringByTrimmingCharactersInSet:ws] forKey:@"baseURL"];
        [d setObject:[tokenField.stringValue stringByTrimmingCharactersInSet:ws] forKey:@"token"];
        self.firstLoad = YES;
        [self.seen removeAllObjects];
        [self poll];
    }
}

#pragma mark - Helpers

- (NSString *)cleanSender:(id)s {
    if (![s isKindOfClass:[NSString class]]) return @"";
    NSString *v = s;
    for (NSString *prefix in @[@"☎️", @"📨", @"📱"]) {
        if ([v hasPrefix:prefix]) v = [v substringFromIndex:prefix.length];
    }
    return [v stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *)ago:(id)iso {
    if (![iso isKindOfClass:[NSString class]]) return @"";
    NSDate *d = [self.iso dateFromString:iso];
    if (!d) return @"";
    NSInteger s = MAX(0, (NSInteger)[[NSDate date] timeIntervalSinceDate:d]);
    if (s < 60) return [self fa:[NSString stringWithFormat:@"%ld ثانیه پیش", (long)s]];
    NSInteger m = s / 60;
    if (m < 60) return [self fa:[NSString stringWithFormat:@"%ld دقیقه پیش", (long)m]];
    NSInteger h = m / 60;
    if (h < 24) return [self fa:[NSString stringWithFormat:@"%ld ساعت پیش", (long)h]];
    return [self fa:[NSString stringWithFormat:@"%ld روز پیش", (long)(h / 24)]];
}

- (NSString *)fa:(NSString *)s {
    NSArray *digits = @[@"۰", @"۱", @"۲", @"۳", @"۴", @"۵", @"۶", @"۷", @"۸", @"۹"];
    NSMutableString *out = [NSMutableString string];
    for (NSUInteger i = 0; i < s.length; i++) {
        unichar c = [s characterAtIndex:i];
        if (c >= '0' && c <= '9') [out appendString:digits[c - '0']];
        else [out appendFormat:@"%C", c];
    }
    return out;
}

@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSApplication *app = [NSApplication sharedApplication];
        AppDelegate *delegate = [[AppDelegate alloc] init];
        app.delegate = delegate;
        [app run];
    }
    return 0;
}
