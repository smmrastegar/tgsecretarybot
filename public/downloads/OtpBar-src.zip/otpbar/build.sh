#!/bin/bash
# Builds OtpBar.app next to this script and opens it.
# Needs Xcode Command Line Tools:  xcode-select --install
#
# Uses the Objective-C source with clang and NO clang modules, so it also
# builds on a CLT install whose Swift module maps are broken
# ("redefinition of module 'SwiftBridging'"). OtpBar.swift is the same
# app in Swift; use `bash build.sh swift` to build that one instead.
set -euo pipefail
cd "$(dirname "$0")"
APP=OtpBar.app
rm -rf "$APP" build
mkdir -p build "$APP/Contents/MacOS" "$APP/Contents/Resources"

if [ "${1:-objc}" = "swift" ]; then
  echo "→ compiling (swift)"
  swiftc -O -target "$(uname -m)-apple-macos12.0" \
    -framework Cocoa -framework UserNotifications -framework ServiceManagement \
    OtpBar.swift -o "$APP/Contents/MacOS/OtpBar"
else
  echo "→ compiling (objective-c)"
  clang -O2 -fobjc-arc -fno-modules -mmacosx-version-min=12.0 \
    -framework Cocoa -framework UserNotifications -framework ServiceManagement \
    OtpBar.m -o "$APP/Contents/MacOS/OtpBar"
fi

cp Info.plist "$APP/Contents/Info.plist"

if command -v iconutil >/dev/null 2>&1 && [ -f icon.png ]; then
  echo "→ icon"
  mkdir -p build/OtpBar.iconset
  for s in 16 32 64 128 256 512; do
    sips -z $s $s icon.png --out "build/OtpBar.iconset/icon_${s}x${s}.png" >/dev/null
    d=$((s*2)); [ $d -le 1024 ] && sips -z $d $d icon.png --out "build/OtpBar.iconset/icon_${s}x${s}@2x.png" >/dev/null
  done
  iconutil -c icns build/OtpBar.iconset -o "$APP/Contents/Resources/OtpBar.icns" || true
fi

echo "→ signing (ad-hoc, local use)"
codesign --force --deep --sign - "$APP"

echo "✓ built $APP"
open "$APP"
